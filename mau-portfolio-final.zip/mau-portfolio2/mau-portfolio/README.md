# Mauricio Ruiz Diaz

Personal portfolio website built for Front-End Programming final project.

React 18 + Vite 5 with React Router v6

- **3 pages:** Home, About, Contact — linked via React Router
- **Dark mode toggle** that persists in `localStorage` and respects `prefers-color-scheme`
- **Typewriter effect** on the Home hero cycling through role descriptions
- **Fully validated contact form** with per-field error messages, `aria-invalid`, `aria-describedby`, and a success state
- **Responsive:** mobile hamburger menu, fluid grid layouts, `clamp()` typography

## Quick start
# 1. Install dependencies
npm install

# 2. Start the dev server
npm run dev
Then open [http://localhost:5173](http://localhost:5173) in your browser.
