import { Link } from 'react-router-dom'

export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="container footer__inner">
        <p className="footer__copy">
          {year} Mauricio Ruiz Diaz, Hamburg, Germany
        </p>

        <nav aria-label="Footer navigation">
          <ul className="footer__links" role="list">
            <li>
              <a
                href="https://github.com/mauuruizd"
                className="footer__link"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Mauricio's GitHub profile (opens in new tab)"
              >
                GitHub
              </a>
            </li>
            <li>
              <a
                href="https://linkedin.com/in/mauricio-ruiz-díaz-a03ba6384"
                className="footer__link"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Mauricio's LinkedIn profile (opens in new tab)"
              >
                LinkedIn
              </a>
            </li>
            <li>
              <Link to="/contact" className="footer__link">
                Contact
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </footer>
  )
}
