import { useState } from 'react'

const MIN_MESSAGE_LENGTH = 20

function validate(fields) {
  const errors = {}

  if (!fields.name.trim()) {
    errors.name = 'Name is required.'
  }

  if (!fields.email.trim()) {
    errors.email = 'Email address is required.'
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email)) {
    errors.email = 'Please enter a valid email address (e.g. name@example.com).'
  }

  if (!fields.message.trim()) {
    errors.message = 'Message is required.'
  } else if (fields.message.trim().length < MIN_MESSAGE_LENGTH) {
    errors.message = `Message must be at least ${MIN_MESSAGE_LENGTH} characters. ` +
      `(${fields.message.trim().length}/${MIN_MESSAGE_LENGTH})`
  }

  return errors
}

const ErrorIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
    aria-hidden="true">
    <circle cx="12" cy="12" r="10"/>
    <line x1="12" y1="8" x2="12" y2="12"/>
    <line x1="12" y1="16" x2="12.01" y2="16"/>
  </svg>
)

const INITIAL = { name: '', email: '', message: '' }

export default function Contact() {
  const [fields,  setFields]  = useState(INITIAL)
  const [errors,  setErrors]  = useState({})
  const [touched, setTouched] = useState({})
  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    const updated = { ...fields, [name]: value }
    setFields(updated)
    if (touched[name]) {
      const newErrors = validate(updated)
      setErrors(prev => ({ ...prev, [name]: newErrors[name] }))
    }
  }

  const handleBlur = (e) => {
    const { name } = e.target
    setTouched(prev => ({ ...prev, [name]: true }))
    const newErrors = validate(fields)
    setErrors(prev => ({ ...prev, [name]: newErrors[name] }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setTouched({ name: true, email: true, message: true })
    const allErrors = validate(fields)
    setErrors(allErrors)

    if (Object.keys(allErrors).length === 0) {
      setSubmitted(true)
    }
  }

  const handleReset = () => {
    setFields(INITIAL)
    setErrors({})
    setTouched({})
    setSubmitted(false)
  }

  const fieldProps = (name) => ({
    id:                 name,
    name:               name,
    value:              fields[name],
    onChange:           handleChange,
    onBlur:             handleBlur,
    'aria-required':    true,
    'aria-invalid':     touched[name] && !!errors[name] ? 'true' : undefined,
    'aria-describedby': touched[name] && errors[name]
      ? `${name}-error`
      : `${name}-hint`,
  })

  return (
    <>
      <section className="page-hero" aria-labelledby="contact-heading">
        <div className="container">
          <h1 className="page-hero__title" id="contact-heading">Let's get in touch!</h1>
          <p className="page-hero__sub">
            Have a project in mind, a Werkstudent offer, or just want to say hello?
            I'd love to hear from you.
          </p>
        </div>
      </section>

      <section className="section" aria-label="Contact information and form">
        <div className="container">
          <div className="contact-layout">

            <aside aria-label="Contact details">
              <h2>Let's connect</h2>
              <p>
                I'm currently looking for an internship and Werkstudent
                opportunities in Hamburg, specially in data science, digital business,
                or product development. Feel free to reach out!
              </p>
            </aside>

            <div>
              <div aria-live="polite" aria-atomic="true">
                {submitted ? (
                  <div className="form-success" role="status">
                    <p style={{ fontSize: '2rem' }} aria-hidden="true">🎉</p>
                    <strong>Message sent</strong>
                    <p>I'll get back to you as soon as possible.</p>
                    <button
                      className="btn btn--outline"
                      onClick={handleReset}
                      style={{ marginTop: '1rem' }}
                    >
                      Send another message
                    </button>
                  </div>
                ) : (
                  <form
                    className="contact-form"
                    onSubmit={handleSubmit}
                    noValidate
                    aria-label="Contact form"
                  >
                    {/* Name */}
                    <div className="form-group">
                      <label className="form-label" htmlFor="name">
                        Name <span className="required" aria-hidden="true">*</span>
                      </label>
                      <input
                        type="text"
                        className="form-input"
                        placeholder="Your full name"
                        autoComplete="name"
                        {...fieldProps('name')}
                      />
                      {touched.name && errors.name ? (
                        <p id="name-error" className="form-error" role="alert">
                          <ErrorIcon /> {errors.name}
                        </p>
                      ) : (
                        <p id="name-hint" className="form-hint">
                          First and last name
                        </p>
                      )}
                    </div>

                    {/* Email */}
                    <div className="form-group">
                      <label className="form-label" htmlFor="email">
                        Email <span className="required" aria-hidden="true">*</span>
                      </label>
                      <input
                        type="email"
                        className="form-input"
                        placeholder="name@example.com"
                        autoComplete="email"
                        inputMode="email"
                        {...fieldProps('email')}
                      />
                      {touched.email && errors.email ? (
                        <p id="email-error" className="form-error" role="alert">
                          <ErrorIcon /> {errors.email}
                        </p>
                      ) : (
                        <p id="email-hint" className="form-hint">
                          I'll reply to this address
                        </p>
                      )}
                    </div>

                    {/* Message */}
                    <div className="form-group">
                      <label className="form-label" htmlFor="message">
                        Message <span className="required" aria-hidden="true">*</span>
                      </label>
                      <textarea
                        className="form-textarea"
                        placeholder="Tell me about your project, opportunity, or question…"
                        {...fieldProps('message')}
                      />
                      {touched.message && errors.message ? (
                        <p id="message-error" className="form-error" role="alert">
                          <ErrorIcon /> {errors.message}
                        </p>
                      ) : (
                        <p id="message-hint" className="form-hint">
                          Minimum {MIN_MESSAGE_LENGTH} characters
                          {fields.message.trim().length > 0 &&
                            ` · ${fields.message.trim().length} typed`}
                        </p>
                      )}
                    </div>

                    <p className="form-hint" style={{ marginTop: '-0.5rem' }}>
                      Fields marked <span aria-hidden="true" style={{ color: 'var(--color-error)' }}>*</span>
                      <span className="sr-only">with an asterisk</span> are required.
                    </p>

                    <button type="submit" className="btn btn--primary">
                      Send message
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
