
const SKILLS = {
  'Programming Languages': ['Python', 'R', 'JavaScript', 'SQL'],
  'Data':            ['Pandas', 'NumPy', 'Matplotlib', 'Plotly', 'Jupyter', 'Machine Learning', 'Data Visualisation'],
  'Web & Tools':          ['React', 'HTML', 'CSS', 'GitHub', 'VS Code', 'Vite'],
  'Soft Skills':              ['Agile Methodologies', 'Scrum', 'Design Thinking', 'Data Analysis', 'Statistical Modelling', 'MoSCoW', 'Teamwork', 'Innovation'],
}

const LANGUAGES = [
  { name: 'Spanish', level: 'Native'},
  { name: 'English', level: 'C2'},
  { name: 'German',  level: 'B2.1'},
  { name: 'French',  level: 'A2'},
]


function AvatarSVG() {
  return (
    <svg
      viewBox="0 0 280 280"
      xmlns="http://www.w3.org/2000/svg"
      className="about-avatar-svg"
      role="img"
      aria-label="Illustrated placeholder avatar for Mauricio Ruiz Diaz"
    >
      {/* Background */}
      <rect width="280" height="280" fill="var(--color-accent-light)" />

      {/* Body */}
      <ellipse cx="140" cy="310" rx="90" ry="70" fill="var(--color-accent)" opacity="0.35" />
      <rect x="90" y="185" width="100" height="80" rx="16" fill="var(--color-accent)" opacity="0.55" />

      {/* Head */}
      <circle cx="140" cy="130" r="62" fill="var(--color-surface-raise)" />
      <circle cx="140" cy="130" r="62" fill="var(--color-accent)" opacity="0.12" />

      {/* Face features */}
      <circle cx="122" cy="120" r="5" fill="var(--color-text)" opacity="0.7" />
      <circle cx="158" cy="120" r="5" fill="var(--color-text)" opacity="0.7" />
      {/* Smile */}
      <path d="M 122 148 Q 140 162 158 148" stroke="var(--color-text)" strokeWidth="3"
            strokeLinecap="round" fill="none" opacity="0.6" />

      {/* Hair */}
      <ellipse cx="140" cy="75" rx="55" ry="28" fill="var(--color-text)" opacity="0.75" />
      <ellipse cx="88"  cy="105" rx="14" ry="30" fill="var(--color-text)" opacity="0.75" />
      <ellipse cx="192" cy="105" rx="14" ry="30" fill="var(--color-text)" opacity="0.75" />

      {/* Collar / shirt hint */}
      <path d="M 108 195 L 140 215 L 172 195" stroke="var(--color-surface-raise)"
            strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.7" />

      {/* Data-viz dots in background (nod to his field) */}
      {[30,50,240,255,20,260].map((x, i) => (
        <circle key={i} cx={x} cy={[240, 255, 245, 230, 260, 260][i]}
                r="4" fill="var(--color-accent)" opacity="0.4" />
      ))}
    </svg>
  )
}

export default function About() {
  return (
    <>
      {/* ── Page hero ── */}
      <section className="page-hero" aria-labelledby="about-heading">
        <div className="container">
          <h1 className="page-hero__title" id="about-heading">A short version of me</h1>
          <p className="page-hero__sub">
            Data science student, multilingual thinker, and sports enthusiast.
          </p>
        </div>
      </section>

      {/* ── Main content ── */}
      <section className="section" aria-label="About Mauricio Ruiz Diaz">
        <div className="container">
          <div className="about-layout">


            <aside aria-label="Profile photo and social links">
              <div className="about-image-wrap">
                <img
                src="/mauricio.png"
                alt="Mauricio Ruiz Diaz smiling"
                className="about-avatar"
                />
                <nav className="about-links" aria-label="Social and contact links">
                  <a
                    href="https://github.com/mauuruizd"
                    className="about-link"
                    target="_blank"
                    rel="noreferrer noopener"
                    aria-label="GitHub profile"
                  >
                    <span aria-hidden="true">🐙</span> github.com/mauuruizd
                  </a>
                  <a
                    href="https://linkedin.com/in/mauricio-ruiz-díaz-a03ba6384"
                    className="about-link"
                    target="_blank"
                    rel="noreferrer noopener"
                    aria-label="LinkedIn profile"
                  >
                    <span aria-hidden="true">💼</span> LinkedIn
                  </a>
                  <a
                    href="mailto:mruizdiaz374@gmail.com"
                    className="about-link"
                    aria-label="Send email to Mauricio"
                  >
                    <span aria-hidden="true">✉️</span> mruizdiaz374@gmail.com
                  </a>
                  <a
                    href="https://maps.google.com/?q=Hamburg,Germany"
                    className="about-link"
                    target="_blank"
                    rel="noreferrer noopener"
                    aria-label="Hamburg, Germany"
                  >
                    <span aria-hidden="true">📍</span> Hamburg, Germany
                  </a>
                </nav>
              </div>
            </aside>

            <div className="about-content">

              {/* Bio */}
              <section aria-labelledby="bio-heading">
                <h2 id="bio-heading">Who I am</h2>
                <div className="about-bio">
                  <p>
                    I'm Mauricio Ruiz Diaz, a Digital Business &amp; Data Science
                    student at the University of Europe of Applied Sciences in Hamburg.
                    Originally from Mexico, I've always been drawn to technology, how data works, and business strategies.
                  </p>
                  <p>
                    I've built several projects throughout my studies: machine learning models,
                    interactive dashboards, among others. These projects have helped me to understand, practice, and polish my habilites.
                  </p>
                  <p>
                    I'm currently seeking an internship (Pflichtpraktikum) or
                    Werkstudent position in Hamburg, ideally in data science, digital
                    business, or product development.
                  </p>
                </div>
              </section>

              <section aria-labelledby="skills-heading">
                <h2 id="skills-heading">Skills</h2>
                {Object.entries(SKILLS).map(([category, items]) => (
                  <div className="skills-group" key={category}>
                    <p className="skills-group__label">{category}</p>
                    <ul className="skills-group__tags" role="list" aria-label={category}>
                      {items.map(skill => (
                        <li key={skill}><span className="tag">{skill}</span></li>
                      ))}
                    </ul>
                  </div>
                ))}
              </section>

              <section aria-labelledby="languages-heading">
                <h2 id="languages-heading">Languages</h2>
                <ul className="lang-grid" role="list">
                  {LANGUAGES.map(({ name, level, flag }) => (
                    <li key={name}>
                      <article className="lang-card">
                        <p className="lang-card__name">
                          <span aria-hidden="true">{flag}</span> {name}
                        </p>
                        <p className="lang-card__level">{level}</p>
                      </article>
                    </li>
                  ))}
                </ul>
              </section>

            </div>
          </div>
        </div>
      </section>
    </>
  )
}
