import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'

const ROLES = [
  'Data Science Student',
  'Digital Business Analyst',
  'Adaptable for anything',
  'Problem Solver',
]
const TYPE_SPEED   = 70   // ms per character
const DELETE_SPEED = 40
const PAUSE_AFTER  = 1800 // ms after full word is typed

function useTypewriter(words) {
  const [displayed, setDisplayed] = useState('')
  const [wordIdx,   setWordIdx]   = useState(0)
  const [deleting,  setDeleting]  = useState(false)

  useEffect(() => {
    const word = words[wordIdx]
    let timeout

    if (!deleting && displayed === word) {
      // Fully typed pause, then start deleting
      timeout = setTimeout(() => setDeleting(true), PAUSE_AFTER)
    } else if (deleting && displayed === '') {
      // Fully deleted then move to next word
      setDeleting(false)
      setWordIdx(i => (i + 1) % words.length)
    } else {
      timeout = setTimeout(() => {
        setDisplayed(prev =>
          deleting ? prev.slice(0, -1) : word.slice(0, prev.length + 1)
        )
      }, deleting ? DELETE_SPEED : TYPE_SPEED)
    }

    return () => clearTimeout(timeout)
  }, [displayed, deleting, wordIdx, words])

  return displayed
}

const PROJECTS = [
  {
    icon: '🤖',
    title: 'Personal CoachBot',
    desc: 'A Python-based AI fitness coach. Tracks workouts, suggests exercises, and provides personalised feedback based on user goals.',
    tags: ['Python', 'Jupyter Notebook', 'CLI'],
    link: 'https://github.com/mauuruizd',
  },
  {
    icon: '📊',
    title: 'Hotel Pricing Dashboard',
    desc: 'Interactive data visualisation dashboard analysing hotel pricing trends across Germany. Built with Python, Pandas, and Plotly for dynamic, filterable insights.',
    tags: ['Python', 'Pandas', 'Plotly'],
    hideLink: true,
  },
]

const ArrowRight = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
    aria-hidden="true">
    <line x1="5" y1="12" x2="19" y2="12"/>
    <polyline points="12 5 19 12 12 19"/>
  </svg>
)

const ExternalIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
    aria-hidden="true">
    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
    <polyline points="15 3 21 3 21 9"/>
    <line x1="10" y1="14" x2="21" y2="3"/>
  </svg>
)

export default function Home() {
  const role = useTypewriter(ROLES)

  return (
    <>
      <section className="hero" aria-labelledby="hero-heading">
        <div className="container hero__content">

          <p className="hero__eyebrow" aria-hidden="true">
            // hello everyone
          </p>

          <h1 className="hero__name" id="hero-heading">
            Hola, I'm{' '}
            <span className="hero__name">Mauricio</span>.
          </h1>

          <p className="hero__role" aria-live="polite" aria-atomic="true">
            {role}
            <span className="hero__cursor" aria-hidden="true" />
          </p>

          <p className="hero__tagline">
            Digital Business &amp; Data Science student at UE of Applied Sciences,
            in Hamburg, I love building data-driven solutions from scratch, and creating new solutions to problems.
          </p>

          <div className="hero__cta">
            <Link to="/about" className="btn btn--primary">
              About me <ArrowRight />
            </Link>
            <Link to="/contact" className="btn btn--outline">
              Let's get in touch
            </Link>
          </div>
        </div>
      </section>

      <section className="section section--alt" aria-labelledby="projects-heading">
        <div className="container">
          <div className="section__header">
            <p className="section__eyebrow" aria-hidden="true">// my work</p>
            <h2 className="section__title" id="projects-heading">
              Featured Projects
            </h2>
          </div>

          <ul className="projects-grid" role="list">
            {PROJECTS.map(project => (
              <li key={project.title}>
                <article className="project-card">
                  <span className="project-card__icon" aria-hidden="true">
                    {project.icon}
                  </span>
                  <h3 className="project-card__title">{project.title}</h3>
                  <p className="project-card__desc">{project.desc}</p>

                  <ul className="project-card__tags" role="list" aria-label="Technologies used">
                    {project.tags.map(t => (
                      <li key={t}><span className="tag">{t}</span></li>
                    ))}
                  </ul>

                  <div className="project-card__footer">
                    {!project.hideLink && (
                    <a
                      href={project.link}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="btn btn--outline"
                      style={{ fontSize: '0.82rem', padding: '0.4rem 0.9rem' }}
                      aria-label={`View ${project.title} on GitHub`}
                    >
                      GitHub <ExternalIcon />
                    </a>
                    )}
                  </div>
                </article>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="section" aria-labelledby="skills-heading">
        <div className="container">
          <div className="section__header">
            <p className="section__eyebrow" aria-hidden="true">// what I use</p>
            <h2 className="section__title" id="skills-heading">
              Core Skills
            </h2>
          </div>

          <ul
            className="project-card__tags"
            role="list"
            aria-label="Technical skills"
            style={{ gap: '0.6rem' }}
          >
            {['Python', 'R', 'JavaScript', 'SQL', 'Innovation',
              'Pandas', 'scikit-learn', 'Machine Learning',
              'Data Visualisation', 'SCRUM', 'Jupyter'].map(skill => (
              <li key={skill}><span className="tag">{skill}</span></li>
            ))}
          </ul>

          <div style={{ marginTop: '2rem' }}>
            <Link to="/about" className="btn btn--outline">
              Full profile <ArrowRight />
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}
